# Alan Test

A website for creators to upload content and set pricing.

## Installation

1. Clone the repository.
2. Navigate to the project directory.
3. Run `npm install` to install dependencies.
4. Run `npm start` to start the server.

## Usage

1. Open your browser and go to `http://localhost:3000`.
2. Register as a creator and upload content.